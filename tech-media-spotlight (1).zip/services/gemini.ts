// Gemini API services have been removed as the application is now static.
export const generateTechArticle = async () => {
  throw new Error("AI generation is disabled.");
};